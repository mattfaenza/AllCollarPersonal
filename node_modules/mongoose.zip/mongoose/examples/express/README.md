Mongoose + Express examples
